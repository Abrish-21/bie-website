// src/pages/index.tsx
import { Header } from '@/components/Header'
import { Footer } from '@/components/Footer'
import { AdSenseSlot } from '@/components/ads/AdSenseSlot'
import SearchFilter from '@/components/SearchFilter'
import { useState, useEffect, Fragment } from 'react'
import { getPosts, getTags, getCategories } from '@/lib/data'
import { Clock, User } from 'lucide-react'
import Link from 'next/link'

export default function HomePage() {
  const [posts, setPosts] = useState<any[]>([])
  const [filteredPosts, setFilteredPosts] = useState<any[]>([])
  const [availableTags, setAvailableTags] = useState<string[]>([])
  const [availableCategories, setAvailableCategories] = useState<string[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  
  // Filter states
  const [searchQuery, setSearchQuery] = useState('')
  const [selectedTag, setSelectedTag] = useState<string | null>(null)
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)

  // Pagination state
  const [currentPage, setCurrentPage] = useState(1);
  const POSTS_PER_PAGE = 9; // 3x3 grid

  useEffect(() => {
    const loadData = async () => {
      try {
        const [postsData, tagsData, categoriesData] = await Promise.all([
          getPosts(),
          getTags(),
          getCategories()
        ])
        
        setPosts(postsData)
        setFilteredPosts(postsData)
        setAvailableTags(tagsData)
        setAvailableCategories(categoriesData)
      } catch (error) {
        console.error('Error loading data:', error)
        setError('Failed to load articles')
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [])

  // Combined filtering logic
  useEffect(() => {
    // Reset to page 1 whenever filters change
    setCurrentPage(1);

    let filtered = posts

    if (searchQuery.trim()) {
      filtered = filtered.filter(post =>
        post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.excerpt.toLowerCase().includes(searchQuery.toLowerCase()) ||
        post.fullContent?.toLowerCase().includes(searchQuery.toLowerCase())
      )
    }

    if (selectedTag) {
      filtered = filtered.filter(post =>
        post.tags && post.tags.includes(selectedTag)
      )
    }

    if (selectedCategory) {
      filtered = filtered.filter(post =>
        post.category === selectedCategory
      )
    }

    setFilteredPosts(filtered)
  }, [posts, searchQuery, selectedTag, selectedCategory])

  const handleSearch = (query: string) => {
    setSearchQuery(query)
  }

  const handleFilterByTag = (tag: string | null) => {
    setSelectedTag(tag)
  }

  const handleFilterByCategory = (category: string | null) => {
    setSelectedCategory(category)
  }

  const clearAllFilters = () => {
    setSearchQuery('')
    setSelectedTag(null)
    setSelectedCategory(null)
    setCurrentPage(1);
  }

  // Pagination logic
  const indexOfLastPost = currentPage * POSTS_PER_PAGE;
  const indexOfFirstPost = indexOfLastPost - POSTS_PER_PAGE;
  const currentPosts = filteredPosts.slice(indexOfFirstPost, indexOfLastPost);
  const totalPages = Math.ceil(filteredPosts.length / POSTS_PER_PAGE);

  const paginate = (pageNumber: number) => {
    if (pageNumber > 0 && pageNumber <= totalPages) {
      setCurrentPage(pageNumber);
      window.scrollTo(0, 0); // Scroll to top on page change
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
            <p className="mt-4 text-gray-600">Loading news...</p>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  if (error) {
    return (
      <div className="min-h-screen bg-white">
        <Header />
        <div className="max-w-7xl mx-auto px-4 py-12">
          <div className="text-center">
            <p className="text-gray-600">{error}</p>
          </div>
        </div>
        <Footer />
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="max-w-7xl mx-auto px-4 py-8">
        <SearchFilter
          onSearch={handleSearch}
          onFilterByTag={handleFilterByTag}
          onFilterByCategory={handleFilterByCategory}
          availableTags={availableTags}
          availableCategories={availableCategories}
        />
      </div>

      {/* Leaderboard Ad */}
      <div className="max-w-7xl mx-auto px-4 mb-8">
        <AdSenseSlot slotId="YOUR_ADSENSE_SLOT_ID_TOP" className="mx-auto" label="Leaderboard" />
      </div>
      
      <main className="max-w-7xl mx-auto px-4">
        <div className="lg:grid lg:grid-cols-12 lg:gap-8">
          {/* Main Content */}
          <div className="lg:col-span-9">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h2 className="text-3xl font-bold text-black">
                  {(searchQuery || selectedTag || selectedCategory) ? 'Filtered Results' : 'Latest News'}
                </h2>
                <p className="text-gray-600 mt-1">
                  {filteredPosts.length === 0 ? 'No articles found' : `Showing ${currentPosts.length} of ${filteredPosts.length} articles`}
                </p>
              </div>
              {(searchQuery || selectedTag || selectedCategory) && (
                <button
                  onClick={clearAllFilters}
                  className="px-4 py-2 text-sm text-gray-600 hover:text-gray-800 transition-colors"
                >
                  Clear filters
                </button>
              )}
            </div>

            {currentPosts.length === 0 ? (
              <div className="text-center py-16 bg-white rounded-lg shadow-sm">
                <p className="text-gray-500 text-lg mb-4">No articles found matching your criteria.</p>
                <button
                  onClick={clearAllFilters}
                  className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  Show all articles
                </button>
              </div>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {currentPosts.map((post, index) => (
                  <Fragment key={post._id || index}>
                    <Link href={`/posts/${post.slug}`} passHref>
                      <article className="bg-white rounded-lg overflow-hidden shadow-sm hover:shadow-md transition-shadow group cursor-pointer flex flex-col h-full">
                        <div className="relative">
                          <img
                            src={post.imageUrl}
                            alt={post.title}
                            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute top-3 left-3">
                            <span className="bg-black bg-opacity-60 text-white px-2 py-1 text-xs font-medium rounded">
                              {post.category}
                            </span>
                          </div>
                        </div>
                        
                        <div className="p-5 flex flex-col flex-grow">
                          <h3 className="text-lg font-bold text-gray-900 group-hover:text-red-600 transition-colors mb-2 leading-tight">
                            {post.title}
                          </h3>
                          <p className="text-gray-600 text-sm leading-relaxed mb-4 flex-grow">
                            {post.excerpt}
                          </p>

                          <div className="flex items-center text-xs text-gray-500 space-x-4 mt-auto pt-3 border-t border-gray-100">
                            <span className="flex items-center">
                              <User className="w-3 h-3 mr-1.5" />
                              {post.author?.name || 'BIE'}
                            </span>
                            <span className="flex items-center">
                              <Clock className="w-3 h-3 mr-1.5" />
                              {post.readTime || '5 min read'}
                            </span>
                          </div>
                        </div>
                      </article>
                    </Link>
                    {/* Inject Ad after every 3rd post (i.e., after each row) */}
                    {(index + 1) % 3 === 0 && index < currentPosts.length -1 && (
                       <div className="md:col-span-2 lg:col-span-3 my-4">
                         <AdSenseSlot slotId={`YOUR_ADSENSE_SLOT_ID_INLINE_${index}`} label="Inline Ad" />
                       </div>
                    )}
                  </Fragment>
                ))}
              </div>
            )}

            {/* Pagination Controls */}
            {totalPages > 1 && (
              <div className="mt-12 flex justify-center items-center gap-4">
                <button
                  onClick={() => paginate(currentPage - 1)}
                  disabled={currentPage === 1}
                  className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Previous
                </button>
                <span className="text-gray-600">
                  Page {currentPage} of {totalPages}
                </span>
                <button
                  onClick={() => paginate(currentPage + 1)}
                  disabled={currentPage === totalPages}
                  className="px-4 py-2 bg-white border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Next
                </button>
              </div>
            )}
          </div>

          {/* Right Sidebar */}
          <aside className="lg:col-span-3 mt-8 lg:mt-0">
            <div className="sticky top-24 space-y-8">
              <div>
                <h3 className="text-xl font-bold text-black mb-4">Advertisement</h3>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <AdSenseSlot slotId="YOUR_ADSENSE_SLOT_ID_SIDEBAR_1" label="Sidebar Ad 1" />
                </div>
              </div>
              <div>
                <div className="bg-white p-4 rounded-lg shadow-sm">
                  <AdSenseSlot slotId="YOUR_ADSENSE_SLOT_ID_SIDEBAR_2" label="Sidebar Ad 2" />
                </div>
              </div>
            </div>
          </aside>
        </div>
      </main>
      
      {/* Footer ad strip */}
      <div className="bg-gray-50 border-t mt-12">
        <div className="max-w-7xl mx-auto px-4 py-6">
          <AdSenseSlot slotId="YOUR_ADSENSE_SLOT_ID_BOTTOM" label="Footer Ad" />
        </div>
      </div>
      <Footer />
    </div>
  )
}