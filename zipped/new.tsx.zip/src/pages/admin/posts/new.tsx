// src/pages/admin/posts/new.tsx

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/router';
import { ArrowLeft, Save, Eye, UploadCloud } from 'lucide-react';
import dynamic from 'next/dynamic';
import { postsAPI } from '../../../lib/api';

// Custom Modal for alerts
interface CustomAlertModalProps {
  message: string;
  onClose: () => void;
}

const CustomAlertModal: React.FC<CustomAlertModalProps> = ({ message, onClose }) => {
  return (
    <div className="fixed inset-0 bg-gray-600 bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white p-6 rounded-lg shadow-xl max-w-md w-full">
        <h3 className="text-lg font-semibold text-gray-900 mb-4">An Error Occurred</h3>
        <pre className="text-gray-700 mb-6 whitespace-pre-wrap text-sm bg-gray-100 p-3 rounded-md">{message}</pre>
        <button
          onClick={onClose}
          className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
        >
          Close
        </button>
      </div>
    </div>
  );
};

// Interface for Post form data (type removed)
interface PostFormData {
  title: string;
  excerpt: string;
  content: string;
  imageUrl: string;
  category: string;
  tags: string[];
  isDraft: boolean;
  readTime: number | string;
  author: string;
  authorId: string;
  fullContent: string;
  seoTitle?: string;
  seoDescription?: string;
  slug?: string;
}

const CATEGORIES = [
  'Business', 'Economy', 'Technology', 'Politics', 'Agriculture', 'Manufacturing',
  'Services', 'Finance', 'Real Estate', 'Tourism', 'Education', 'Healthcare'
];

const TiptapEditor = dynamic(() => import('../../../components/TiptapEditor'), { ssr: false });

export default function NewPost() {
  const router = useRouter();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);
  const [previewMode, setPreviewMode] = useState(false);
  const [formData, setFormData] = useState<PostFormData>({
    title: '',
    excerpt: '',
    content: '',
    imageUrl: '',
    category: 'Business',
    tags: [],
    isDraft: false,
    readTime: '',
    author: '',
    authorId: '',
    fullContent: '',
    seoTitle: '',
    seoDescription: '',
  });
  const [tagInput, setTagInput] = useState('');
  const [alertMessage, setAlertMessage] = useState<string | null>(null);
  const [selectedImageFile, setSelectedImageFile] = useState<File | null>(null);
  const [imagePreviewUrl, setImagePreviewUrl] = useState<string | null>(null);

  useEffect(() => {
    const userData = localStorage.getItem('user');
    if (!userData) {
      router.push('/admin/login');
      return;
    }
    try {
      const parsedUser = JSON.parse(userData);
      setUser(parsedUser);
      setFormData(prev => ({
        ...prev,
        author: parsedUser.name || 'Admin',
        authorId: parsedUser._id,
      }));
    } catch (error) {
      console.error('Failed to parse user data:', error);
      router.push('/admin/login');
    }
  }, [router]);

  const handleInputChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  }, []);

  const handleEditorContentChange = useCallback((html: string) => {
    setFormData(prev => ({ ...prev, content: html, fullContent: html }));
  }, []);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setSelectedImageFile(file);
      setImagePreviewUrl(URL.createObjectURL(file));
      setFormData(prev => ({ ...prev, imageUrl: '' }));
    } else {
      setSelectedImageFile(null);
      setImagePreviewUrl(null);
    }
  }, []);

  const handleAddTag = useCallback(() => {
    if (tagInput.trim() && !formData.tags.includes(tagInput.trim())) {
      setFormData(prev => ({ ...prev, tags: [...prev.tags, tagInput.trim()] }));
      setTagInput('');
    }
  }, [tagInput, formData.tags]);

  const handleRemoveTag = useCallback((tagToRemove: string) => {
    setFormData(prev => ({ ...prev, tags: prev.tags.filter(tag => tag !== tagToRemove) }));
  }, []);

  const uploadImage = async (file: File): Promise<string> => {
    setUploadingImage(true);
    try {
      const imageFormData = new FormData();
      imageFormData.append('image', file);
      const response = await fetch('/api/upload-image', { method: 'POST', body: imageFormData });
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.error || 'Image upload failed');
      }
      const data = await response.json();
      if (!data.imageUrl) {
        throw new Error('Image URL not found in upload response.');
      }
      return data.imageUrl;
    } finally {
      setUploadingImage(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setAlertMessage(null);

    if (!formData.title || !formData.content || !formData.category || !formData.readTime) {
      setAlertMessage('Please fill in all required fields: Title, Content, Category, and Read Time.');
      setLoading(false);
      return;
    }

    try {
      let finalImageUrl = formData.imageUrl;

      if (selectedImageFile) {
        finalImageUrl = await uploadImage(selectedImageFile);
      }
      
      if (!finalImageUrl) {
        setAlertMessage('Image is required. Please upload a file or provide a URL.');
        setLoading(false);
        return;
      }

      const postData = {
        ...formData,
        imageUrl: finalImageUrl,
        readTime: String(formData.readTime),
        slug: formData.title.toLowerCase().replace(/[^a-z0-9\s-]/g, '').replace(/\s+/g, '-').replace(/(^-|-$)/g, ''),
      };

      await postsAPI.create(postData);
      router.push('/admin/dashboard?postCreated=true');

    } catch (error: any) {
      console.error('Error creating post:', error);
      const errorMessage = error.response?.data?.error || error.message || 'Failed to create post';
      const errorDetails = error.response?.data?.details;
      let finalMessage = errorMessage;
      if (errorDetails) {
        const detailsString = Object.entries(errorDetails).map(([key, val]: [string, any]) => `${key}: ${val.message}`).join('\n');
        finalMessage += `\n\nDetails:\n${detailsString}`;
      }
      setAlertMessage(finalMessage);
    } finally {
      setLoading(false);
    }
  };

  if (!user) {
    return <div className="min-h-screen bg-gray-50 flex items-center justify-center"><p>Loading...</p></div>;
  }

  const currentImageSource = imagePreviewUrl || formData.imageUrl;

  return (
    <div className="min-h-screen bg-gray-50">
      {alertMessage && <CustomAlertModal message={alertMessage} onClose={() => setAlertMessage(null)} />}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <button onClick={() => router.push('/admin/dashboard')} className="flex items-center space-x-2 text-gray-600 hover:text-gray-800">
                <ArrowLeft className="h-4 w-4" />
                <span>Back to Dashboard</span>
              </button>
              <div className="h-6 w-px bg-gray-300"></div>
              <h1 className="text-2xl font-bold text-gray-900">Create New Post</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button type="button" onClick={() => setPreviewMode(!previewMode)} className="flex items-center space-x-2 px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50">
                <Eye className="h-4 w-4" />
                <span>{previewMode ? 'Edit' : 'Preview'}</span>
              </button>
              <button type="submit" form="post-form" disabled={loading || uploadingImage} className="flex items-center space-x-2 bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50">
                <Save className="h-4 w-4" />
                <span>{loading ? 'Saving...' : uploadingImage ? 'Uploading...' : 'Save Post'}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        {previewMode ? (
          <div className="bg-white shadow-sm rounded-lg p-6">
            {currentImageSource && <img src={currentImageSource} alt={formData.title || 'Post Image'} className="w-full h-64 object-cover rounded-lg mb-6" />}
            <h1 className="text-3xl font-bold text-gray-900 mb-4">{formData.title || 'Untitled Post'}</h1>
            <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: formData.content || '<p>No content yet...</p>' }} />
          </div>
        ) : (
          <form id="post-form" onSubmit={handleSubmit} className="space-y-6">
            <div className="bg-white shadow-sm rounded-lg p-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="title" className="block text-sm font-medium text-gray-700 mb-2">Title *</label>
                  <input type="text" required name="title" value={formData.title} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg" placeholder="Enter post title..." />
                </div>
                <div>
                  <label htmlFor="category" className="block text-sm font-medium text-gray-700 mb-2">Category *</label>
                  <select required name="category" value={formData.category} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg">
                    {CATEGORIES.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
                </div>
                <div>
                  <label htmlFor="readTime" className="block text-sm font-medium text-gray-700 mb-2">Read Time (minutes) *</label>
                  <input type="number" required name="readTime" value={formData.readTime} onChange={handleInputChange} className="w-full px-3 py-2 border border-gray-300 rounded-lg" placeholder="e.g., 5" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Status</label>
                  <div className="flex items-center space-x-4">
                    <label className="flex items-center"><input type="radio" name="isDraft" checked={!formData.isDraft} onChange={() => setFormData(p => ({ ...p, isDraft: false }))} className="mr-2" />Publish</label>
                    <label className="flex items-center"><input type="radio" name="isDraft" checked={formData.isDraft} onChange={() => setFormData(p => ({ ...p, isDraft: true }))} className="mr-2" />Save as Draft</label>
                  </div>
                </div>
                <div className="lg:col-span-2">
                  <label htmlFor="imageUpload" className="block text-sm font-medium text-gray-700 mb-2">Featured Image *</label>
                  <div className="flex items-center space-x-2 mb-2">
                    <input type="file" id="imageUpload" accept="image/*" onChange={handleFileChange} className="hidden" />
                    <label htmlFor="imageUpload" className="flex items-center space-x-2 px-4 py-2 border rounded-lg cursor-pointer hover:bg-gray-50">
                      <UploadCloud className="h-4 w-4" />
                      <span>{selectedImageFile ? 'Change File' : 'Choose File'}</span>
                    </label>
                    <span className="text-sm text-gray-500">OR</span>
                    <input type="url" name="imageUrl" value={formData.imageUrl} onChange={handleInputChange} placeholder="Paste Image URL" className="flex-1 px-3 py-2 border rounded-lg" disabled={!!selectedImageFile} />
                  </div>
                  {currentImageSource && <div className="mt-2"><img src={currentImageSource} alt="Preview" className="max-w-full h-32 object-cover rounded-md" /></div>}
                </div>
              </div>
              <div className="mt-6">
                <label htmlFor="excerpt" className="block text-sm font-medium text-gray-700 mb-2">Excerpt</label>
                <textarea name="excerpt" value={formData.excerpt} onChange={handleInputChange} rows={3} className="w-full px-3 py-2 border rounded-lg" placeholder="Brief summary..."></textarea>
              </div>
              <div className="mt-6">
                <label htmlFor="tags" className="block text-sm font-medium text-gray-700 mb-2">Tags</label>
                <div className="flex items-center space-x-2 mb-3">
                  <input type="text" value={tagInput} onChange={e => setTagInput(e.target.value)} onKeyPress={e => e.key === 'Enter' && (e.preventDefault(), handleAddTag())} className="flex-1 px-3 py-2 border rounded-lg" placeholder="Add a tag and press Enter..." />
                  <button type="button" onClick={handleAddTag} className="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700">Add</button>
                </div>
                {formData.tags.length > 0 && <div className="flex flex-wrap gap-2">{formData.tags.map(tag => <span key={tag} className="inline-flex items-center px-3 py-1 bg-blue-100 text-blue-800 text-sm rounded-full">{tag}<button type="button" onClick={() => handleRemoveTag(tag)} className="ml-2 text-blue-600 hover:text-blue-800">&times;</button></span>)}</div>}
              </div>
              <div className="mt-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">Content *</label>
                <TiptapEditor initialContent={formData.content} onContentChange={handleEditorContentChange} />
              </div>
            </div>
          </form>
        )}
      </div>
    </div>
  );
}