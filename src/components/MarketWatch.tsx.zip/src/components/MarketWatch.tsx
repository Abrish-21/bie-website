// src/components/MarketWatch.tsx

import { TrendingUp, TrendingDown, Clock } from 'lucide-react';
import Link from 'next/link';
import { useEffect, useState } from 'react';
import { getPosts } from '../lib/data';

export function MarketWatch() {
  const [marketWatchArticles, setMarketWatchArticles] = useState<any[]>([]);

  useEffect(() => {
    const load = async () => {
      try {
        const posts = await getPosts();
        setMarketWatchArticles(posts.slice(0, 4)); // Fetching 4 articles for a 2x2 grid
      } catch (e) {
        setMarketWatchArticles([]);
      }
    };
    load();
  }, []);

  return (
    <section className="bg-white py-12">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl font-bold text-black mb-8">Market Watch</h2>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {marketWatchArticles.map((article, index) => (
            <Link key={index} href={`/posts/${article.slug}`} passHref>
              <article className="group cursor-pointer">
                <div className="relative mb-4">
                  <img
                    src={article.imageUrl}
                    alt={article.title}
                    className="w-full h-40 object-cover rounded-lg group-hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <h3 className="text-xl font-bold text-black group-hover:text-red-600 transition-colors mb-2 leading-tight">
                  {article.title}
                </h3>
                <div className="flex items-center text-sm text-gray-500">
                  <Clock className="w-4 h-4 mr-1" />
                  <span>{article.readTime}</span>
                </div>
              </article>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
